﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class volume : MonoBehaviour
{

    public Slider volSlider;
    private AudioSource ost;

    // Start is called before the first frame update
    void Start()
    {
        var audioClips = GetComponents<AudioSource>();
        ost = audioClips[0];
    }

    // Update is called once per frame
    void Update()
    {
        ost.volume = volSlider.value;
    }
}
